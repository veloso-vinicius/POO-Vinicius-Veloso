package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Fábrica de conexões com o PostgreSQL.
 * Os valores podem ser sobrescritos por variáveis de ambiente
 * (DB_URL, DB_USER, DB_PASSWORD) para não deixar senha fixa no GitHub.
 */
public class ConnectionFactory {

    private static final String URL =
            System.getenv().getOrDefault("DB_URL", "jdbc:postgresql://localhost:5432/poo_exercicios");
    private static final String USER =
            System.getenv().getOrDefault("DB_USER", "postgres");
    private static final String PASSWORD =
            System.getenv().getOrDefault("DB_PASSWORD", "postgres");

    private ConnectionFactory() {
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver PostgreSQL não encontrado. Verifique a pasta lib/.", e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
