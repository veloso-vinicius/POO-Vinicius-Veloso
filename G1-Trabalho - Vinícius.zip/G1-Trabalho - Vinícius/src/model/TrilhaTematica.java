package model;

public class TrilhaTematica {

    private int id;
    private String nome;
    private String salaDesignada;

    public TrilhaTematica() {
    }

    public TrilhaTematica(String nome, String salaDesignada) {
        this.nome = nome;
        this.salaDesignada = salaDesignada;
    }

    public TrilhaTematica(int id, String nome, String salaDesignada) {
        this.id = id;
        this.nome = nome;
        this.salaDesignada = salaDesignada;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSalaDesignada() {
        return salaDesignada;
    }

    public void setSalaDesignada(String salaDesignada) {
        this.salaDesignada = salaDesignada;
    }

    @Override
    public String toString() {
        return "TrilhaTematica{id=" + id + ", nome='" + nome + "', salaDesignada='" + salaDesignada + "'}";
    }
}
