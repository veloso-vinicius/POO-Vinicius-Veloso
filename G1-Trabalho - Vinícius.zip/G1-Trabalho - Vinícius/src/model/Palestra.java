package model;

public class Palestra {

    private int id;
    private String titulo;
    private String palestrante;
    private int duracaoMinutos;
    private TrilhaTematica trilha;

    public Palestra() {
    }

    public Palestra(String titulo, String palestrante, int duracaoMinutos, TrilhaTematica trilha) {
        this.titulo = titulo;
        this.palestrante = palestrante;
        this.duracaoMinutos = duracaoMinutos;
        this.trilha = trilha;
    }

    public Palestra(int id, String titulo, String palestrante, int duracaoMinutos, TrilhaTematica trilha) {
        this(titulo, palestrante, duracaoMinutos, trilha);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getPalestrante() {
        return palestrante;
    }

    public void setPalestrante(String palestrante) {
        this.palestrante = palestrante;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }

    public void setDuracaoMinutos(int duracaoMinutos) {
        this.duracaoMinutos = duracaoMinutos;
    }

    public TrilhaTematica getTrilha() {
        return trilha;
    }

    public void setTrilha(TrilhaTematica trilha) {
        this.trilha = trilha;
    }

    @Override
    public String toString() {
        return "Palestra{id=" + id + ", titulo='" + titulo + "', palestrante='" + palestrante
                + "', duracaoMinutos=" + duracaoMinutos + ", trilha=" + trilha + "}";
    }
}
