package dao;

import model.TrilhaTematica;
import util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TrilhaTematicaDAO {

    public void salvar(TrilhaTematica trilha) throws SQLException {
        String sql = "INSERT INTO trilha_tematica (nome, sala_designada) VALUES (?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, trilha.getNome());
            ps.setString(2, trilha.getSalaDesignada());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    trilha.setId(keys.getInt(1));
                }
            }
        }
    }

    public TrilhaTematica buscarPorId(int id) throws SQLException {
        String sql = "SELECT id, nome, sala_designada FROM trilha_tematica WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<TrilhaTematica> listarTodos() throws SQLException {
        String sql = "SELECT id, nome, sala_designada FROM trilha_tematica ORDER BY id";
        List<TrilhaTematica> lista = new ArrayList<>();
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public boolean atualizar(TrilhaTematica trilha) throws SQLException {
        String sql = "UPDATE trilha_tematica SET nome = ?, sala_designada = ? WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, trilha.getNome());
            ps.setString(2, trilha.getSalaDesignada());
            ps.setInt(3, trilha.getId());
            return ps.executeUpdate() > 0;
        }
    }

    /** Remove a trilha. Por causa do ON DELETE CASCADE, as palestras dela também são removidas. */
    public boolean deletar(int id) throws SQLException {
        String sql = "DELETE FROM trilha_tematica WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private TrilhaTematica mapear(ResultSet rs) throws SQLException {
        return new TrilhaTematica(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("sala_designada"));
    }
}
