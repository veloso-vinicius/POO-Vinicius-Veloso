package dao;

import model.Palestra;
import model.TrilhaTematica;
import util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PalestraDAO {

    private static final String SELECT_JOIN =
            "SELECT p.id, p.titulo, p.palestrante, p.duracao_minutos, "
            + "t.id AS trilha_id, t.nome AS trilha_nome, t.sala_designada "
            + "FROM palestra p INNER JOIN trilha_tematica t ON p.trilha_id = t.id ";

    public void salvar(Palestra palestra) throws SQLException {
        String sql = "INSERT INTO palestra (titulo, palestrante, duracao_minutos, trilha_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, palestra.getTitulo());
            ps.setString(2, palestra.getPalestrante());
            ps.setInt(3, palestra.getDuracaoMinutos());
            ps.setInt(4, palestra.getTrilha().getId());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    palestra.setId(keys.getInt(1));
                }
            }
        }
    }

    /** Busca pontual já trazendo a trilha associada (INNER JOIN). */
    public Palestra buscarPorId(int id) throws SQLException {
        String sql = SELECT_JOIN + "WHERE p.id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    /** Lista todas as palestras com os dados da trilha (INNER JOIN). */
    public List<Palestra> listarTodos() throws SQLException {
        String sql = SELECT_JOIN + "ORDER BY t.nome, p.titulo";
        List<Palestra> lista = new ArrayList<>();
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    /** Lista as palestras de uma trilha específica (INNER JOIN). */
    public List<Palestra> listarPorTrilha(int trilhaId) throws SQLException {
        String sql = SELECT_JOIN + "WHERE t.id = ? ORDER BY p.titulo";
        List<Palestra> lista = new ArrayList<>();
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, trilhaId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    public boolean atualizar(Palestra palestra) throws SQLException {
        String sql = "UPDATE palestra SET titulo = ?, palestrante = ?, duracao_minutos = ?, trilha_id = ? WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, palestra.getTitulo());
            ps.setString(2, palestra.getPalestrante());
            ps.setInt(3, palestra.getDuracaoMinutos());
            ps.setInt(4, palestra.getTrilha().getId());
            ps.setInt(5, palestra.getId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deletar(int id) throws SQLException {
        String sql = "DELETE FROM palestra WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Palestra mapear(ResultSet rs) throws SQLException {
        TrilhaTematica trilha = new TrilhaTematica(
                rs.getInt("trilha_id"),
                rs.getString("trilha_nome"),
                rs.getString("sala_designada"));
        return new Palestra(
                rs.getInt("id"),
                rs.getString("titulo"),
                rs.getString("palestrante"),
                rs.getInt("duracao_minutos"),
                trilha);
    }
}
