package app;

import dao.PalestraDAO;
import dao.TrilhaTematicaDAO;
import model.Palestra;
import model.TrilhaTematica;

import java.sql.SQLException;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        TrilhaTematicaDAO trilhaDAO = new TrilhaTematicaDAO();
        PalestraDAO palestraDAO = new PalestraDAO();

        try {
            // 1) INSERÇÃO: lado "1" (trilha) e depois lado "N" (palestras)
            System.out.println("=== 1) Inserindo trilha e palestras ===");
            TrilhaTematica ia = new TrilhaTematica("Inteligência Artificial", "Sala 101");
            trilhaDAO.salvar(ia);
            System.out.println("Trilha salva: " + ia);

            Palestra p1 = new Palestra("Introdução a Redes Neurais", "Dra. Ana Souza", 45, ia);
            Palestra p2 = new Palestra("IA Generativa na Prática", "Carlos Lima", 60, ia);
            palestraDAO.salvar(p1);
            palestraDAO.salvar(p2);
            System.out.println("Palestra salva: " + p1);
            System.out.println("Palestra salva: " + p2);

            TrilhaTematica nuvem = new TrilhaTematica("Nuvem", "Sala 202");
            trilhaDAO.salvar(nuvem);
            palestraDAO.salvar(new Palestra("Arquitetura Serverless", "Marina Rocha", 50, nuvem));

            // 2) LISTAGEM com INNER JOIN
            System.out.println("\n=== 2) Listagem com INNER JOIN ===");
            for (Palestra p : palestraDAO.listarTodos()) {
                System.out.printf("[%s | %s] %s - %s (%d min)%n",
                        p.getTrilha().getNome(), p.getTrilha().getSalaDesignada(),
                        p.getTitulo(), p.getPalestrante(), p.getDuracaoMinutos());
            }

            System.out.println("\n--- Palestras da trilha '" + ia.getNome() + "' ---");
            for (Palestra p : palestraDAO.listarPorTrilha(ia.getId())) {
                System.out.println(p);
            }

            // 3) BUSCA POR ID
            System.out.println("\n=== 3) Busca por ID ===");
            System.out.println(palestraDAO.buscarPorId(p1.getId()));

            // 4) ATUALIZAÇÃO
            System.out.println("\n=== 4) Atualização ===");
            p1.setDuracaoMinutos(90);
            p1.setTitulo("Redes Neurais: do Zero ao Deploy");
            palestraDAO.atualizar(p1);
            ia.setSalaDesignada("Auditório Principal");
            trilhaDAO.atualizar(ia);
            System.out.println("Depois de atualizar: " + palestraDAO.buscarPorId(p1.getId()));

            // 5) REMOÇÃO
            System.out.println("\n=== 5) Remoção ===");
            palestraDAO.deletar(p2.getId());
            System.out.println("Palestra removida. Restantes da trilha IA: "
                    + palestraDAO.listarPorTrilha(ia.getId()).size());

            // Integridade referencial: ON DELETE CASCADE remove as palestras da trilha
            trilhaDAO.deletar(ia.getId());
            System.out.println("Trilha IA removida (CASCADE apagou as palestras dela).");
            System.out.println("Palestra p1 ainda existe? " + (palestraDAO.buscarPorId(p1.getId()) != null));

            // Limpeza do restante dos dados de teste
            trilhaDAO.deletar(nuvem.getId());

            System.out.println("\n=== Trilhas restantes no banco ===");
            List<TrilhaTematica> restantes = trilhaDAO.listarTodos();
            restantes.forEach(System.out::println);

        } catch (SQLException e) {
            System.err.println("Erro de banco de dados: " + e.getMessage());
            System.err.println("SQLState: " + e.getSQLState());
        }
    }
}
