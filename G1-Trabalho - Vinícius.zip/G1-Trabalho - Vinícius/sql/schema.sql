-- Execute no banco poo_exercicios
-- CREATE DATABASE poo_exercicios;

CREATE TABLE trilha_tematica (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sala_designada VARCHAR(50) NOT NULL
);

CREATE TABLE palestra (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(180) NOT NULL,
    palestrante VARCHAR(120) NOT NULL,
    duracao_minutos INT NOT NULL,
    trilha_id INT NOT NULL REFERENCES trilha_tematica(id) ON DELETE CASCADE
);
